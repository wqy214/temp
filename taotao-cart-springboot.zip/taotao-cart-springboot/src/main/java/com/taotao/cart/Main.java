package com.taotao.cart;

import org.springframework.boot.SpringApplication;

import com.taotao.cart.spring.config.TaotaoApplication;

public class Main {
    
    public static void main(String[] args) {
        SpringApplication.run(TaotaoApplication.class, args);
    }

}
