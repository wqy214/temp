package com.taotao.cart.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.cart.pojo.Cart;

public interface CartMapper extends Mapper<Cart>{

}
